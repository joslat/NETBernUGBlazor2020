﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using BlazorSWAPI.Shared.SWAPI;
using Microsoft.AspNetCore.Components;

namespace BlazorSWAPI.Client.Repository
{
    public class FilmRestRepository : IFilmRepository
    {
        private readonly HttpClient HttpCli;

        public FilmRestRepository(HttpClient httpcli)
        {
            this.HttpCli = httpcli;
        }

        public async Task<List<Film>> GetAll()
        {
            List<Film> filmReceived = null;

            try
            {
                var RootObj =
            await HttpCli.GetJsonAsync<SharpEntityResults<Film>>(SWAPIRestConfig.FilmsUrl);

                filmReceived = RootObj.results;

            }
            catch (Exception ex)
            {
                // throw;
                return null;
            }

            return filmReceived;
        }

        public async Task<Film> GetFilmById(int id)
        {
            Film f = null;

            try
            {
                f = await HttpCli.GetJsonAsync<Film>($"{SWAPIRestConfig.FilmsUrl}{id}/" );
            }
            catch (Exception ex)
            {
                // throw;
                return null;
            }

            return f;
        }
    }
}
