﻿using BlazorSWAPI.Shared.SWAPI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorSWAPI.Client.Repository
{
    public interface IFilmRepository
    {
        Task<List<Film>> GetAll();
        Task<Film> GetFilmById(int id);
    }
}
