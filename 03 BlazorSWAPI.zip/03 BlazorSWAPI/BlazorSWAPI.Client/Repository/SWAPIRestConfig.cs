﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorSWAPI.Client.Repository
{
    public static class SWAPIRestConfig
    {
		private static string _SWAPI_RootUrl = "https://swapi.co/api/";
		private static string _SWAPI_FilmsEndpoint = "films/";

		public static string RootUrl
		{
			get { return _SWAPI_RootUrl; }
		}

		public static string FilmsUrl
		{
			get { return _SWAPI_RootUrl + _SWAPI_FilmsEndpoint; }
		}


	}
}
