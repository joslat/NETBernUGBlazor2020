﻿using System;
using System.Collections.Generic;

namespace BlazorSWAPI.Shared.SWAPI
{
    /// <summary>
    /// A Star Wars film
    /// </summary>
    public class Film : SharpEntity
    {
        /// <summary>
        /// The episode number of this film.
        /// </summary>
        public short episode_id
        {
            get;
            set;
        }

        /// <summary>
        /// The vehicle resources featured within this film.
        /// </summary>
        public List<string> vehicles
        {
            get;
            set;
        }

        /// <summary>
        /// The url of this resource
        /// </summary>
        public string url
        {
            get;
            set;
        }

        /// <summary>
        /// An array of starship resources that this person has piloted
        /// </summary>
        public List<string> starships
        {
            get;
            set;
        }

        /// <summary>
        /// The title of this film.
        /// </summary>
        public string title
        {
            get;
            set;
        }


        public string release_date
        {
            get;
            set;
        }

        /// <summary>
        /// The url of the species resource that this person is.
        /// </summary>
        public List<string> species
        {
            get;
            set;
        }

        /// <summary>
        /// The producer(s) of this film.
        /// </summary>
        public string producer
        {
            get;
            set;
        }

        /// <summary>
        /// The planet resources featured within this film.
        /// </summary>
        public List<string> planets
        {
            get;
            set;
        }

        /// <summary>
        /// The director of this film.
        /// </summary>
        public string director
        {
            get;
            set;
        }

        /// <summary>
        /// The people resources featured within this film.
        /// </summary>
        public List<string> characters
        {
            get;
            set;
        }

        /// <summary>
        /// The opening crawl text at the beginning of this film.
        /// </summary>
        public string opening_crawl
        {
            get;
            set;
        }

        public string Poster {
            get {
                return "https://media.gettyimages.com/photos/film-poster-for-george-lucas-film-star-wars-an-american-epic-fiction-picture-id513667727?s=612x612";
            }
        }

        public string TitleBrief
        {
            get
            {
                if (string.IsNullOrEmpty(title))
                {
                    return null;
                }

                if (title.Length > 60)
                {
                    return title.Substring(0, 60) + "...";
                }
                else
                {
                    return title;
                }
            }
        }

        public string Year
        {
            get
            {
                string year = "1900";

                DateTime dt = Convert.ToDateTime(release_date);
                year = dt.Year.ToString();
                return year;
            }
        }

        public DateTime ReleaseDate
        {
            get
            {
                DateTime dt = Convert.ToDateTime(release_date);
                return dt;
            }            
        }
    }
}