﻿namespace BlazorSWAPI.Shared.SWAPI
{
    public abstract class SharpEntity
    {
    }
}