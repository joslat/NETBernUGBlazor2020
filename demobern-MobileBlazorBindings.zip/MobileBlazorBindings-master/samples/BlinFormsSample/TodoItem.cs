﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

namespace BlinFormsSample
{
    public class TodoItem
    {
        public bool IsDone { get; set; }

        public string Text { get; set; }
    }
}
