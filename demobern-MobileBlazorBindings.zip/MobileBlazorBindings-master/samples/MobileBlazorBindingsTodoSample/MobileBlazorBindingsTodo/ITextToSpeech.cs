﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

namespace MobileBlazorBindingsTodo
{
    public interface ITextToSpeech
    {
        void Speak(string text);
    }
}
