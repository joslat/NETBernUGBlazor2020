﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

using System;

namespace BlinForms.Framework
{
    public interface IBlinFormsRootFormContent
    {
        Type RootFormContentType { get; }
    }
}
