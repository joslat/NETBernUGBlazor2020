﻿namespace ComponentWrapperGenerator
{
    public class GeneratorSettings
    {
        public string FileHeader { get; set; }
        public string RootNamespace { get; set; }
    }
}
