﻿// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

namespace Microsoft.MobileBlazorBindings
{
    public interface ICustomChildProcessor
    {
        void SetChild(object child);
    }
}
